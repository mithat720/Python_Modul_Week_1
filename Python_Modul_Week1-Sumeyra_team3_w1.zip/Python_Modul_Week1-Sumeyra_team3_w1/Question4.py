#Get a number from the user and write a Python code that prints whether this number is odd or even.
num = int(input("Enter a number: "))
if num % 2 == 0:  #Check if the number is even
    print("The number is even.")
else:
    print("The number is odd.")
