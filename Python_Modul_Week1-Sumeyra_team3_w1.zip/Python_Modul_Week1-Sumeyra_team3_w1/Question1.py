# Write a python code that prints numbers from 1 to 10 on the screen.

for i in range(1, 11):  #for i in means we loop through those numbers one by one.
                        #range(1, 11) generates numbers starting from 1 up to, but not including, 11
    print(i)